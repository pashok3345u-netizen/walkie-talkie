@echo off
chcp 65001 >nul
title Walkie-Talkie
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  pause
)
